from leitor_csv import LeitorCsv
from perceptron import Perceptron


leitor = LeitorCsv("../dados/credito.csv")

amostras, saidas = leitor.carregarDados()


rede = Perceptron(amostras, saidas)

rede.treinar()


while True:

    historico = float(input("Histórico de crédito: "))
    renda = float(input("Renda mensal: "))

    resultado = rede.teste([historico, renda])


    if resultado == 1:
        print("Cliente Aprovado")

    else:
        print("Cliente Recusado")