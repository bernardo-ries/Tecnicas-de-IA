import csv

class LeitorCsv:

    def __init__(self, nomeArquivo):
        self.nomeArquivo = nomeArquivo

    def carregarDados(self):
        amostras = []
        saidas = []

        with open(self.nomeArquivo, newline='', encoding='utf-8') as arquivo:
            leitor = csv.reader(arquivo)

            next(leitor)

            for linha in leitor:
                amostras.append([
                    float(linha[0]),
                    float(linha[1])
                ])

                saidas.append(int(linha[2]))

        return amostras, saidas