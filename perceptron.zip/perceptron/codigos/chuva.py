from leitor_csv import LeitorCsv
from perceptron import Perceptron


leitor = LeitorCsv("../dados/chuva.csv")

amostras, saidas = leitor.carregarDados()


rede = Perceptron(amostras, saidas)

rede.treinar()


while True:

    umidade = float(input("Umidade: "))
    pressao = float(input("Pressão: "))

    resultado = rede.teste([umidade, pressao])


    if resultado == 1:
        print("Classe: Chuva")

    else:
        print("Classe: Sol")